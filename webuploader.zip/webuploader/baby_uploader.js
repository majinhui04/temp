define(function(require,exports){

    window.Uploader = Uploader;
    var imageTypes = 'image/gif,image/jpg,image/jpeg,image/png';
    var imageMaxSize = 1024*1024*10;//10M
    var videoTypes = 'video/mp4,video/mov';
    var videoMaxSize = 1024*1024*10;//10M
    var uploadParams = {};

    var _uuid = 0, 
        uploadform = [
            '/api/1.1b/file/upyun/photo/uploadform',
            '/api/1.1b/file/upyun/avatar/uploadform',
            '/api/1.1b/file/upyun/image/uploadform',
            '/api/1.1b/file/upyun/video/uploadform'
        ],
        callbackurl = [
            '/api/1.1b/file/upyun/form/',
            '/api/1.1b/file/upyun/form/',
            '/api/1.1b/file/upyun/form/'
        ],
        defaultOptions = {
            mode: 1, // 1: 普通照片上传 2: 上传头像 3: 上传封面 4:video
            success: null,
            error: null,
            override:false,
            type:'image',
            remove:true,//显示删除
            timeout: 60*10
        };
    var uploadError = {
        'Not accept, Bucket not exists' : '不接受请求,空间不存在',
        'Authorize has expired' : '不接受请求,上传授权已过期',
        'Not accept, Miss signature' : '不接受请求,缺少签名',
        'Not accept, Signature error' : '签名错误',
        'Not accept, POST URI error' : '不接受请求',
        'Not accept, Bucket disabled' : '不接受请求,空间被禁用',
        'Not accept, Form API disabled' : '不接受请求,表单 API 功能未打开',
        'Not accept, No file data' : '不接受请求,没有上传文件数据',
        'Not accept, File too large' : '不接受请求,上传文件过大 (大小限制{maxsize}M)',
        'Not accept, File too small' : '不接受请求,上传文件过小 ',
        'Not accept, File type Error' : '不接受请求,上传文件类型不允许',
        'Not accept, Content­md5 error' : '不接受请求,上传文件的内容 md5 校验错误',
        'Not accept, Not a image file' : '不接受请求,上传的不是图片文件',
        'Not accept, Image width too small' : '不接受请求,上传的图片宽度过小 (宽度范围 {minwidth}px 到 {maxwidth}px,大小限制{maxsize}M)',
        'Not accept, Image width too large' : '不接受请求,上传的图片宽度过大 (宽度范围 {minwidth}px 到 {maxwidth}px,大小限制{maxsize}M)',
        'Not accept, Image height too small' : '不接受请求,上传的图片高度过小(最小高度 {minheight}px,最大高度{maxheight}px,大小限制{maxsize}M)',
        'Not accept, Image height too large' : '不接受请求,上传的图片高度过大(最小高度 {minheight}px,最大高度{maxheight}px,大小限制{maxsize}M)',
        'Not accept, Data too long for ext-param' : ' 额外参数内容过长，2012/11/12 新增',
        'Image Rotate Invalid Parameters' : '图片旋转参数错误',
        'Image Crop Invalid Parameters' : '图片裁剪参数错误',
        'System Error ... Retry again' : '系统错误,请再尝试'
    };
    //获取图片宽 和 高
    function imgReady(url, success, error) {
        var width, height, intervalId, check, div,
            img = new Image(),
            body = document.body;
            
        img.src = url;
        
        // 从缓存中读取
        if (img.complete) {
            return success(img.width, img.height);
        }
        // 通过占位提前获取图片头部数据
        if (body) {
            div = document.createElement('div');
            div.style.cssText = 'position:absolute;left:-99999px;top:0;';
            div.appendChild(img);
            body.appendChild(div);
            width = img.offsetWidth;
            height = img.offsetHeight;
           
            check = function () {
               
                if (img.offsetWidth !== width || img.offsetHeight !== height) {
                    
                    clearInterval(intervalId);
                    success(img.offsetWidth, img.clientHeight);
                    img.onload = null;
                    div.innerHTML = '';
                    div.parentNode.removeChild(div);
                };

            };
            
            intervalId = setInterval(check, 150);
        }
        
        // 加载完毕后方式获取
        img.onload = function () {
            if(img.complete){
                success(img.width, img.height);
                img.onload = img.onerror = null;
                clearInterval(intervalId);
                body && img.parentNode &&img.parentNode.removeChild(img);
            }
                
        };
        
        // 图片加载错误
        img.onerror = function () {
            error && error();
            clearInterval(intervalId);
            body && img.parentNode && img.parentNode.removeChild(img);
        };
        
    }
    // 预加载图片
    function getPicInfo(file) {
        var reader = new FileReader();
        var dfd = $.Deferred();
        reader.onload = function(e) {
            var url = e.target.result,size = e.total || 0;
            
            imgReady(url,function(width,height){
                dfd.resolve({
                    url:url,
                    width:width,
                    height:height,
                    size:size
                });
            },function(){
                dfd.reject();
            });
            
        };
        reader.onerror = function(e) {
            dfd.reject();
        };
        reader.readAsDataURL(file);

        return dfd.promise(); 
    }
    function xhrErrorHandle(xhr,action){
        var responseText,fail = ' 错误来源: '+action,error={message:' 错误信息: 未知 '+fail};
        var isResponseObject=function(xhr){
            return /^{/.test(xhr.responseText);
        };

        if(xhr.message){
            error = xhr;
            error.message = error.message || '';
            error.message += fail;
        }
        else if(isResponseObject(xhr) && xhr.status == 500){
            
            try{
                responseText = xhr.responseText.replace('/\\/g','//');
                error = $.parseJSON(responseText) ;
                console.warn(action,error);
                error.message = error.message || '未知。';
                error.message = ' 错误信息: '+ error.message ;
                error.message += fail;
                
            }catch(e){
                console.warn('responseText parse error')
                //error = {message:'xhr error 1'+fail};
            }
        }else if( isResponseObject(xhr) ){
            responseText = xhr.responseText.replace('/\\/g','//');
            try{
                error = $.parseJSON(responseText) ;
                console.warn(action,error);
                error.message = error.message || '未知。';
                error.message = ' 错误信息: '+ error.message ;
                error.message += fail;
            }catch(e){
                console.warn('responseText parse error')
                error = {message:'xhr error 2'+fail};
            }
        }
        
        error.status = xhr.status;
        //console.warn('return ajax error',error);
        return error;
    }
    function uuid() {
        return ++_uuid;
    }

    function substitute(str, obj) {
        if (!(Object.prototype.toString.call(str) === '[object String]')) {
            return '';
        }
        if(!(Object.prototype.toString.call(obj) === '[object Object]' && 'isPrototypeOf' in obj)) {
            return str;
        }
        //    /\{([^{}]+)\}/g
        return str.replace(/\{(.*?)\}/igm , function(match, key) {
            if(obj[key]!=null || obj[key]!=undefined){
                return obj[key];
            }
            return '';
        });
    }

    function handleError(message){
        var minwith,maxwidth,minheight,maxheight,minsize,maxsize,result='';

        message = message.replace(/\+/g," ");
        message = decodeURIComponent(message);
        uploadParams.maxsize = uploadParams.maxsize/1024/1024;
         for(var msg in uploadError){
            if(msg == message){
                message = uploadError[msg];
                result = substitute(message, uploadParams);
            }
        }

        return result;
    }


    function Uploader(form, options) {
        var self=this;


        this.options = $.extend({}, defaultOptions, options);

        this._$form = $(form);
        this._$box = options.$box;
        this.suffix = options.suffix;
        this._init();
        //若是图片 且提供 $box
        if(this._$box && this.options.mode != 4 && this.options.remove ){
            this._$box.addClass('upload-img-box').append('<span class="upload-img-del"></span>');
            this._$box.delegate('.upload-img-del','click',function(){
                self.removeImg();
                options.close && options.close.call(self);
                
            });
            //若是视频 且提供 $box
        }else if(this._$box && this.options.mode == 4 && this.options.remove){
            this._$box.addClass('upload-img-box').append('<span class="upload-img-del"></span>');
            this._$box.delegate('.upload-img-del','click',function(){
                if(options.close){
                    options.close.call(self);
                }else{
                    self.removeVideo();
                }
                
            });
        }
    }

    Uploader.prototype = {
        constructor: Uploader,

        _init: function() {
            var _this = this;
            this._uuid = uuid();

            this._$iframe = $('<iframe />');
            this._$iframe[0].name = 'Uploader'+this._uuid;
            this._$iframe[0].id = this._$iframe[0].name;

            this._$iframe.hide();

            this._$policy = $(this._hidden('policy'));
            this._$signature = $(this._hidden('signature'));
            this._$file = $('input[type=file]', this._$form);


            this._$form[0].target = this._$iframe[0].name;

            this._$form.append(this._$policy).append(this._$signature);

            $('body').append(this._$iframe);

            // 自动上传
            if(this.options.auto){
                this._$file.unbind();
                this._$file.bind('change',function(){

                    _this.submit();
                });
            }
            
            
            window['upload_callback_'+this._uuid] = function(result) {
               
                clearTimeout(_this._timer);
  
                _this._$file[0].value = '';

                if (_this._isTimeout) {
                    return;
                }
                //删除loading
                _this._removeLoading();

                console.log('upload callback result ',result)
                if (result.code == 200) {
                    if (result.url) {
                        result.url = decodeURIComponent(result.url);
                    }
                    console.log('upload ok ',result,result.url);
                    result.url = _this._domain + result.url;
                    

                    //显示图片 || 视频
                    if(_this.options.mode == 4){
                        _this.showVideo(result.url);
                    }else{
                        _this.showImg(result.url);
                        _this._$box.find('img').attr('data-src',result.url);
                    }
                    

                    if ($.isFunction(_this.options.success)) {
                        _this.options.success.call(_this, result);
                    }
                }
                else {
                    console.warn('callback return error',result)
                    if ($.isFunction(_this.options.error)) {
                        // damon update
                        result.message = handleError(result.message);
                        /*result.message=result.message.replace(/\+/g," ");
                        result.message=decodeURIComponent(result.message);
                         for(var msg in uploadError){
                            if(msg==result.message){
                                result.message=uploadError[msg];
                                result.message=result.message.replace('{minwidth}',_this.minwidth);
                            }
                        }*/
                        _this.options.error.call(_this, result);
                    }
                }
            }
        },

        _hidden: function(name, value) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = value;
            return input;
        },
        _renderLoading:function(){
            var self=this,$box=self._$box,$file=self._$file,fileName,tpl;

            tpl='<div class="upload-loading-box">'+
                    '<span class="upload-loading-icon"></span>'+
                    '<span class="upload-loading-txt">{txt}</span>'+
                '</div>';
            if(!$box){
                return;
            }
            fileName = $file.val();
            console.log('file ',$file.val());
            if(fileName.length>15){
                fileName = '...'+(fileName+' ').slice(-14,-1);
            }
            $box.append(tpl.replace('{txt}',fileName));
            
        },
        _removeLoading:function(){
            var self=this,$box=self._$box;

            if(!$box){
                return;
            }
            $box.find('.upload-loading-box').remove();
        },
        removeImg:function(){
            var self=this,$box=self._$box;

            self._$file.val('');
            $box.find('img').remove();
        },
        removeVideo:function(){
            var self=this,$box=self._$box;

            self._$file.val('');
            $box.find('video').remove();
        },
        showImg:function(url){
            var self=this,$box=self._$box,suffix = self.suffix || '';
            
            if(self.options.preview && (self.options.override === false)){
                self._$file.val('');
                return;
            }
            if(!$box){
                return;
            }
            if (suffix) {
                url+=suffix;
            };
            self.removeImg();
            $box.prepend('<img src="'+url+'" class="uplaod-img">');

        },
        showVideo:function(url){
            var self=this,$box=self._$box;

            if(!$box){
                return;
            }
            self.removeVideo();
            $box.prepend('<video src="'+url+'" preload="none" class="uplaod-video" controls="controls">您的浏览器不支持此种视频格式。</video>');
        },
        fileValidate:function(){
            var self=this,file = this._$file[0].files[0];

            if(this.options.mode ==4 ){
                if(videoTypes.indexOf(file.type) == -1 || file.type ==''){
                    alert('视频格式需为'+videoTypes);
                    return false;
                }
                if(file.size>videoMaxSize){
                    alert('大小不可超过'+videoMaxSize/1024000+'M！');
                    return false;
                }
            }else{
                if(imageTypes.indexOf(file.type) == -1 || file.type ==''){
                    alert('图片格式需为'+imageTypes);
                    return false;
                }
                if(file.size>imageMaxSize){
                    alert('大小不可超过'+imageMaxSize/1024000+'M！');
                    return false;
                }
            }

            return true;
        },
        submit:function(){
            var self= this,files = this._$file[0].files,file = files[0],options = this.options,mode = options.mode,
                failCallback = options.error;

            console.log('file',file);
            if (!file) {
                alert('请选择需要上传的文件');
                return;
            }
            //普通照片
            if(mode == 1){
                
                //验证是图片文件
                if( file && file.type.indexOf('image')>-1 ){
                    getPicInfo(file).done(function(result){
                        console.log('pic',result);
                        if ( result.width < 800 && result.height < 800 ) {
                            failCallback && failCallback.call(self,{message:'您上传的照片太小了,照片宽或者高应大于800像素'});
                            return;
                        }
                        if ( result.size >= imageMaxSize  ) {
                            failCallback && failCallback.call(self,{message:'照片大小应小于10M'});
                            return;
                        }
                        // 预览 
                        if(self._$box && self.options.preview){
                            self._$box.find('img').remove();
                            self._$box.prepend('<img src="'+result.url+'" class="uplaod-img">');
                        }
                        self._submit();
                        

                    }).fail(function(){
                        failCallback && failCallback.call(self,{message:'读取文件失败'});
                    });

                }else{
                    failCallback && failCallback.call(self,{message:'请上传图片文件'});
                }
                    

            }
            // 头像 128
            else if(mode == 2){
                //验证是图片文件
                if( file && file.type.indexOf('image')>-1 ){
                    getPicInfo(file).done(function(result){
                        console.log('pic',result);
                        if ( result.width <128 ) {
                            failCallback && failCallback.call(self,{message:'您上传的照片不符合尺寸,宽至少应为 128px '});
                            return;
                        }
                        if ( result.size >= imageMaxSize  ) {
                            failCallback && failCallback.call(self,{message:'照片大小应小于10M'});
                            return;
                        }
                        // 预览 
                        if(self._$box && self.options.preview){
                            self._$box.find('img').remove();
                            self._$box.prepend('<img src="'+result.url+'" class="uplaod-img">');
                        }
                        self._submit();
                        

                    }).fail(function(){
                        failCallback && failCallback.call(self,{message:'读取文件失败'});
                    });

                }else{
                    failCallback && failCallback.call(self,{message:'请上传图片文件'});
                }
            }
            //封面 mode=3
            else if(mode == 3){
                //验证是图片文件
                if( file && file.type.indexOf('image')>-1 ){
                    getPicInfo(file).done(function(result){
                        console.log('pic',result);
                        /*if ( result.width !=427 || result.height !=640 ) {
                            failCallback && failCallback.call(self,{message:'您上传的照片不符合尺寸,大小应为 427px * 640px '});
                            return;
                        }*/
                        if ( result.size >= imageMaxSize  ) {
                            failCallback && failCallback.call(self,{message:'照片大小应小于10M'});
                            return;
                        }
                        // 预览 
                        if(self._$box && self.options.preview){
                            self._$box.find('img').remove();
                            self._$box.prepend('<img src="'+result.url+'" class="uplaod-img">');
                        }
                        self._submit();
                        

                    }).fail(function(){
                        failCallback && failCallback.call(self,{message:'读取文件失败'});
                    });

                }else{
                    failCallback && failCallback.call(self,{message:'请上传图片文件'});
                }
            }
            else if(mode == 4){
                if( file && file.type.indexOf('mp4')>-1 ){
                    if(file.size < videoMaxSize ){
                        self._submit();
                    }else{
                        failCallback && failCallback.call(self,{message:'视频大小应小于10M'});
                    }
                }else{
                    failCallback && failCallback.call(self,{message:'请上传mp4文件'});
                }
            }else{
                self._submit();
            }
        },
        _submit: function() {
            var _this = this,semesterid = window['currentSemester']?window['currentSemester'].id :'';

            this.stopSubmit=false;
           
           /* if(!_this.fileValidate()){
                return;
            }*/

            var url = uploadform[this.options.mode-1],
                callback = 'http://'+location.host,
                params = {};

            callback += callbackurl[0];
            callback += 'uploadcallback_'+_this._uuid+'?semesterid='+semesterid;
            //callback += _this._uuid + '&';
            params.returnurl = callback;
            params.semesterid = semesterid;
            $.extend(true, params, _this.options.params);
            
            
            //
            _this._renderLoading();


            $.ajax({
                'url': url,
                'type': 'post',
                'data': params
            }).done(done).fail(fail);

            
            _this._isTimeout = false;
            _this._timer = setTimeout(function() {
                if ($.isFunction(_this.options.error)) {
                    _this.options.error.call(_this,{
                        'message': '请求超时'
                    });
                }

                _this._isTimeout = true;
            }, 1000 * _this.options.timeout);

            function done(result) {
                var $form;
                console.log('params:',params,',url:',url,',result:',result);
                console.log('ready to upload');
                uploadParams = result.data;
                if (result.code == 0) {
                    console.log('begin upload ',_this._$form);
                    
                    _this._$form.attr('action', result.data.action);
                    _this._$policy.val(result.data.policy);
                    _this._$signature.val(result.data.signature);
                    _this._$form.find('input[type=file]').attr('name', 'file');
                    _this._$form.submit();
                    console.log('end upload ');
                    _this._domain = 'http://' + result.data.domain;
                    return;
                }

                fail(result);
            }

            function fail(xhr) {
                
                _this._removeLoading();
                console.warn('fail ready to upload',xhr);
                var error = xhrErrorHandle(xhr,'获取上传数据');

                if ($.isFunction(_this.options.error)) {
                    _this.options.error.call(_this,error);
                }
            }
        }
    };

});
