<?php
header("Content-type: text/html; charset=utf-8"); 
header("Access-Control-Allow-Headers: authorization, content-type");
header("Access-Control-Allow-Methods: OPTIONS, HEAD, POST");
//header("Access-Control-Allow-Origin:*");
header("Access-Control-Allow-Origin:http://jj.com");

//$targetFolder = '/uploads'; // upload path
$targetPath = dirname(__FILE__).'/../app/storage/uploads'; 

$tempFile = $_FILES['file']['tmp_name'];
//
//$targetPath =  $RootDir.$targetFolder;
$targetFile = rtrim($targetPath,'/') . '/' . $_FILES['file']['name'];


//$fileParts = pathinfo($_FILES['file']['name']);
move_uploaded_file($tempFile, $targetFile);

echo '{"code":1,"path":""}';
//echo "<script>top.upload_callback_1({url:'".$targetFile."'});</script>";


?>