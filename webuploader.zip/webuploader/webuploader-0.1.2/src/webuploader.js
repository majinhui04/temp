/**
 * @fileOverview Uploader上传类
 */
define([
    './preset/all'
], function( preset ) {
    return preset;
});