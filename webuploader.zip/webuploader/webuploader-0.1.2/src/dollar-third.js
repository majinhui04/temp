/**
 * @fileOverview jQuery or Zepto
 */
define(function() {
    return window.jQuery || window.Zepto;
});